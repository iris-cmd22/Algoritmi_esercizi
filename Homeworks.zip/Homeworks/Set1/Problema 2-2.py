#Sia data un vettore di n numeri interi positivi. 
# Si considerino le sotto-sequenze i cui valori sono ordinati 
# in senso crescente (si assume che non ci siano duplicati). 
# Si scriva un programma per trovare la somma massima tra le 
# somme degli elementi di tali sottosequenza.

#Ad esempio, se l'array di input è {3, 4, 5, 10}, 
# l'output dovrebbe essere 22 (3 + 4 + 5 + 10); 
# se l'array di input è {10, 5, 4, 3}, 
# l'output dovrebbe essere 10.

#
def MaxSomma_ordinata(A):
    
    n=len(A)
    sum=[-1]*(n+1)
    
    #Caso base
    sum[0]=0
    sum[1]=A[0]
    
    for i in range (1,n):
        if(A[i]>A[i-1]):
            sum[i+1]=sum[i]+A[i]
        else:
            sum[i+1]=A[i]
     
    print("\nVettore di somme: \n")   
    print(sum)
    return max(sum)
    
    

#Funzione di lettura da file
def readTestFile(path):
    try: 
        testsList = []
        with open(path, 'r') as file:
            for line in file:
                line = line.strip() #così tolgo gli spazi
                if line:
                    numbers=[]
                    for x in line.split():
                        try:
                            numbers.append(int(x))
                        except ValueError:
                            print(f"Errore alla riga {line.strip()}: '{x}'. Devi inserire numeri interi!")
                            break #Analizzo solo i caratteri corretti
                    testsList.append(numbers)
    except FileNotFoundError:
        print(f"File {path} non trovato.")
    
    return testsList

if __name__=="__main__":
    
    #try:
        #input da tastiera
        #print("Inserisci n numeri interi separato da spazi: ")
        #array_n = input()
        
        testsList = readTestFile(path="./Test22.txt")

        for test in testsList:
            
            if not test:
                break
            
            print("\nArray: ")
            print(test)
            
            A=MaxSomma_ordinata(test)
            print("\nSomma: \n")
            print(A)
            
            
    #except ValueError:
    #    print("Devi inserire numeri interi!")