#Problema 2.3
#Un numero può sempre essere rappresentato come somma di quadrati di altri numeri. 
# Infatti, al limite, il valore 1 è un quadrato e possiamo sempre rappresentare un 
# qualsiasi numero come (1*1 + 1* 1 + 1*1 + …).
#Dato un numero n, si implementi un algoritmo che trova il numero minimo di quadrati 
# la cui somma è n. Ad esempio, se n = 100, questo valore si può ottenere sommando 
# $5^2$ +$5^2$ +$5^2$ +$5^2$, quindi usando 4 quadrati, ma anche come $10^2$, 
# quindi usando un solo quadrato.
#Si alleghi al PDF un file editabile riportante l’implementazione in un linguaggio a scelta, 
# corredato da almeno tre casi di test con il corrispondente output atteso

def QuadSum(n):
    
    dp=[0]*(n+1)
    
    for i in range (n+1):
        dp[i]=i #numero massimo di quadrati possibile (1*1+1*1+1*1+...)
        
        j=1
        while j*j<=i: #se il quadrato è minore del massimo
            dp[i]=min(dp[i],1+dp[i-j*j]) #prendiamo il numero minimo fra ciò che avevamo prima e il nuovo quadrato da considerare
            j +=1
            
    return dp[n]

#Funzione di lettura da file
def readTestFile(path):
    try: 
        testsList = []
        with open(path, 'r') as file:
            for line in file:
                line = line.strip() #così tolgo gli spazi
                if line:
                    numbers=[]
                    for x in line.split():
                        try:
                            
                            if(int(x)<0):
                                raise ValueError
                            numbers.append(int(x))
                            
                        except ValueError:
                            print(f"Errore alla riga {line.strip()}: '{x}'. Devi inserire numeri interi e positivi!")
                            break #Analizzo solo i caratteri corretti
                    testsList.append(numbers)
    except FileNotFoundError:
        print(f"File {path} non trovato.")
    
    return testsList

if __name__=="__main__":
    
    #try:
        #input da tastiera
        #print("Inserisci n numeri interi separato da spazi: ")
        #array_n = input()
        
        testsList = readTestFile(path="./Test23.txt")

        for test in testsList:
            
            if not test:
                break
            
            print("\n Number: "+str(test[0]))
            print("\n Somma: "+str(QuadSum(test[0])))
            
            
    #except ValueError:
    #    print("Devi inserire numeri interi!")