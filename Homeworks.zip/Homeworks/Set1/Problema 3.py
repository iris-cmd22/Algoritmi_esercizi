#Problema 3.1

#La S.S.C. Napoli è interessata a massimizzare i guadagni 
# derivanti dagli ingressi allo stadio. 
# Ti hanno assunto come consulente per aumentare le vendite 
# dei “biglietti per gruppi” di tifosi. 

#Bisogna risolvere il seguente problema: 
# quando un gruppo vuole vedere una partita, 
# tutti i membri del gruppo devono avere un posto, 
# altrimenti se ne vanno. 

#Quindi, poiché non vi possono essere gruppi “parziali”, 
# le gradinate spesso non sono piene. C'è ancora spazio disponibile, 
# ma non abbastanza per un intero gruppo. 
# In tal caso, il gruppo non può sedersi, e il Napoli perde soldi. 

#Si sviluppi un algoritmo per decidere quali gruppi far entrare 
# per massimizzare le vendite.

def MaxSales(gruppi, posti): #mi prendo il vettore dei gruppi a cui assegnere il posto e il numero di posti disponibili
    
    #inizializzazione della matrice dp (gruppo da includere)*(posti_disponibili)
    dp = [[0 for _ in range(posti + 1)] for _ in range(len(gruppi) + 1)] 
   
    #CASO BASE
    for i in range(len(gruppi) + 1): #con 0 posti non includo nessuno
        dp[i][0] = 0

    for j in range(posti + 1): #con 0 gruppi occupo 0 posti
        dp[0][j] = 0    
    
    #print(dp)
    
    for i in range(1, len(gruppi) + 1):  #per ogni gruppo
        for j in range(1, posti + 1):       #per ogni posto
            
			#Se il gruppo entra in una fila
            if (gruppi[i - 1] <=j):  
                #includiamo il gruppo se ci fa guadagnare di più rispetto al non includerlo
                dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - gruppi[i - 1]] + gruppi[i - 1]) 
            else:
                # altrimenti escludiamo il gruppo
                dp[i][j] = dp[i - 1][j]
    #print(dp)

    #Dei gruppi che possono entrare voglio prendermi quelli che mi occupano il maggior numero di posti disponibili
    maxsale=dp[len(gruppi)][posti] #La vendita più cospiscua che posso ottenere
    gruppi_inclusi=[] 
    
    for i in range(len(gruppi),0,-1):
        
        if (maxsale>0) and (maxsale != dp[i-1][posti]): #le la vendita è dievrsa da quella che avrei non facendoli sedere
            
            gruppi_inclusi.append(gruppi[i-1]) #mi salvo il gruppo
            posti -=gruppi[i-1] #consideriamo i posti rimasti
            maxsale -=gruppi[i-1]
    
    return gruppi_inclusi

#Funzione di lettura da file
def readTestFile(path):
    try: 
        testsList = []
        with open(path, 'r') as file:
            for line in file:
                line = line.strip() #così tolgo gli spazi
                if line:
                    numbers=[]
                    for x in line.split():
                        try:
                            if(int(x)<0):
                                raise ValueError
                            numbers.append(int(x))
                            #print(numbers)
                        except ValueError:
                            print(f"Errore alla riga {line.strip()}: '{x}'. Devi inserire numeri interi e positivi!")
                            break #Analizzo solo i caratteri corretti
                    testsList.append(numbers)
                    #print(testsList)
    except FileNotFoundError:
        print(f"File {path} non trovato.")
    
    return testsList

if __name__ == "__main__":
    
    
    testsList = readTestFile(path="./test_napoli.txt")
    
    i=0
    
    for test in testsList:
            
        if not test:
            break
        
        if (i==0 or i%2==0):
            n = test[0]
            print("\nIn ",n, " posti")
        else:
            gruppi = test
            soluzione=MaxSales(gruppi, n)
            print("dei gruppi ",gruppi," faccio entrare ",soluzione," vendendo quindi ",sum(soluzione)," biglietti")
              
        i+=1