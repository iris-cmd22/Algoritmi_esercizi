'''
Sia A[1 . . n] un array di n elementi distinti “quasi ordinato”, 
ovvero in cui ogni elemento dell’array si trova entro k slot dalla sua posizione corretta. 
Definiamo una "inversione": se i<j e A[i] > A[j], allora la coppia (i,j) è detta inversione di A. 
Si implementi un algoritmo che ordina il vettore A in tempo (n lg k). Suggerimento: Si usi un Heap
Si alleghi al PDF un file editabile riportante l’implementazione in un linguaggio a scelta, corredato da almeno tre casi di test'''

### Funzioni per l'ordinamento di un vettore 

#MAX-HEAPIFY 
#Serve a conservare la proprietà del max heap, viene chiamata quanto gli alberi con radici Left(i) e Righht(i) sono max-heap
#ma A[i] è il più piccolo dei suoi figli, violando la proprietà dell'heap    
def Max_Heapify(A,n,i):
    
    massimo=i #inizializziamo la radice
    
    l=2*i+1 #figlio sinistro
    r=2*i+2 #figlio destro
    
    #Se il nodo non è una foglia e ho un massimo in l
    if l < n and A[l]>A[i]:
        massimo=l
    
    #Se il nodo non è una foglia e ho un massimo in r
    if r < n and A[r]>A[massimo]:
        massimo=r
    
    if massimo != i: #Posso farlo scendere ancora
        (A[i],A[massimo])=(A[massimo],A[i])
        
        Max_Heapify(A,n,massimo)
            
            
def Build_Max_Heap(A):
    for i in range (len(A)//2,-1,-1):
        Max_Heapify(A,len(A),i)
    return A

#HeapSort
def HeapSort(A):
      
    A=Build_Max_Heap(A)
    n = len(A)
    for i in range(n-1, 0, -1):
          # Swap
          A[i], A[0] = A[0], A[i]
  
          # Heapify root element
          Max_Heapify(A, i, 0)
    return A

#Funzione di lettura da file
def readTestFile(path):
    try: 
        testsList = []
        with open(path, 'r') as file:
            for line in file:
                line = line.strip() #così tolgo gli spazi
                if line:
                    numbers=[]
                    for x in line.split():
                        try:
                            if(int(x)<0):
                                raise ValueError
                            numbers.append(int(x))
                        except ValueError:
                            print(f"Errore alla riga {line.strip()}: '{x}'. Devi inserire numeri interi e positivi!")
                            break #Analizzo solo i caratteri corretti
                    testsList.append(numbers)
    except FileNotFoundError:
        print(f"File {path} non trovato.")
    
    return testsList

if __name__=="__main__":
    
    #try:
        #input da tastiera
        #print("Inserisci n numeri interi separato da spazi: ")
        #array_n = input()
        
        testsList = readTestFile(path="./Test13.txt")

        for test in testsList:
            
            if not test:
                break
            
            print("\nArray: ")
            print(test)
            print("\nHEAPSORT: \n")
            A=HeapSort(test)
            print(A)
            
            
    #except ValueError:
    #    print("Devi inserire numeri interi!")