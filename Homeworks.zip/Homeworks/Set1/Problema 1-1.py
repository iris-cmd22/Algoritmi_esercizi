'''
PROBLEMA 1
Si implementi un algoritmo di ordinamento che sfrutta l’inserimento e 
la visita in un albero binario di ricerca. 
Dato un vettore di n numeri interi in input, 
l’algoritmo procede prima ad inserire i numeri in un albero binario 
di ricerca (usando ripetutamente TREE-INSERT per inserire i numeri uno alla volta), 
e poi stampa i numeri in ordine con un attraversamento in ordine simmetrico dell’albero. 
Si analizzi la complessità nel caso peggiore e nel caso migliore di per questo algoritmo di ordinamento.
Si alleghi al PDF un file editabile riportante l’implementazione in un linguaggio a scelta, 
corredato da almeno tre casi di test
'''
class BSTreeNode:
    def __init__(self,key):
        self.key=key
        self.left=None
        self.right=None
        
#Attraversamento di un BST
def Inorder_Tree_walk(x):
    if x is not None:
        Inorder_Tree_walk(x.left)
        print(x.key, end=" ")
        Inorder_Tree_walk(x.right)

'''Complessità \Theta n '''

#Inserimento di un BST
def Tree_insert(root,key):
    
    #Se la radice è nulla 
    if root is None:
        #viene inserito un nuovo nodo con la chiave data nella radice
        return BSTreeNode(key)
    
    #Se la chiave sta nella radice
    if root.key == key:
        #ritorno la radice
        return root
    
    #Se la chiave è maggiore del valore della radice
    if root.key < key:
        #esploro il sottoalbero destro con chiamata ricorsiva
        root.right = Tree_insert(root.right, key)
    else:
        #altrimenti il sinistro
        root.left =Tree_insert(root.left, key)
    return root


#Funzione di lettura da file
def readTestFile(path):
    try: 
        testsList = []
        with open(path, 'r') as file:
            for line in file:
                line = line.strip() #così tolgo gli spazi
                if line:
                    numbers=[]
                    for x in line.split():
                        try:
                            if(int(x)<0):
                                raise ValueError
                            numbers.append(int(x))
                        except ValueError:
                            print(f"Errore alla riga {line.strip()}: '{x}'. Devi inserire numeri interi e positivi!")
                            break #Analizzo solo i caratteri corretti
                    testsList.append(numbers)
    except FileNotFoundError:
        print(f"File {path} non trovato.")
    
    return testsList

if __name__=="__main__":
    
    #try:
        #input da tastiera
        #print("Inserisci n numeri interi separato da spazi: ")
        #array_n = input()
        
        testsList = readTestFile(path="./Test1.txt")
        

        for test in testsList:
            
            if not test:
                break
            
            r=None
            for n in test:
                r=Tree_insert(r,n)
                
            #Visita in order dell'albero
            print('\n')
            Inorder_Tree_walk(r)
            
            
    #except ValueError:
    #    print("Devi inserire numeri interi!")
        