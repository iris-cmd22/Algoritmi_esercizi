'''
Si implementi un algoritmo che, a partire da un vettore di n numeri interi in input, 
costruisce un heap chiamando ripetutamente la procedura `MAX-HEAP-INSERT`per inserire gli elementi nell’heap. 
L’algoritmo di costruzione ha il seguente pseudocodice:

BUILD-MAX-HEAP_v2(A)
A.heap_size=1
for(i=2) to A.lenght
    MAX-HEAP-INSERT(A,A[i])

Si alleghi al PDF un file editabile riportante l’implementazione in un linguaggio a scelta, corredato da almeno tre casi di test
Si confronti la `BUILD-MAX-HEAP` vista a lezione con la `BUILD-MAX-HEAP_v2`, in particolare: 
le due procedure creano sempre lo stesso heap se vengono eseguite con lo stesso array di input? 
Dimostrare che lo fanno o fornite un controesempio.
Dimostrare che, nel caso peggiore, `BUILD-MAX-HEAP_v2` richiedo un tempo **$Θ(n\ logn)$** per costruire un heap di n elementi.'''

#MAXHEAP    
class MaxHeap:
    def __init__(self, maxsize):
        #Mi serve il numero di elementi massimo per inizializzarlo
        self.maxsize =maxsize
        self.size=0
        self.maxHeap=[0]*(self.maxsize + 1) #Inizializzo tutti 0
        
    #Per le proprietà dell'heap
    #Se voglio conoscere la posizione del genitore
    def parent(self,i):
        return i // 2
    
    #Se voglio la posizione del figlio sinistro
    def leftChild(self,i):
        return 2*i
    
    #Se voglio la posizone del figlio destro
    def rightChild(self, i):
        return (2*i)+1
    
    #Se voglio sapere se sono in una foglia
    def isLeaf(self,i):
        
        if i>=(self.size//2) and i>=self.size:
            return True
        return False
    
    #Se voglio scambiare due elementi dell'heap
    def scambia(self, pos1, pos2):
        self.maxHeap[pos1], self.maxHeap[pos2]=(self.maxHeap[pos2],self.maxHeap[pos1])
        
    def inserisci(self, element):
         
        if self.size >= self.maxsize:
            return
        self.size += 1
        self.maxHeap[self.size] = element
 
        current = self.size
 
        while (self.maxHeap[current] > 
               self.maxHeap[self.parent(current)]):
            self.scambia(current, self.parent(current))
            current = self.parent(current)

# Function to insert a node into the heap
    def insert(self, element):
         
        if self.size >= self.maxsize:
            print("Added too many elements!")
            return
        self.size += 1
        #Aggiungiamo un elemento all'array
        self.maxHeap[self.size] = element
        #Prendiamoci l'indice dell'elemento appena aggiunto
        current = self.size
 
        #Se l'elemento appena aggiunto è più grande del padre, scambio i due nodi
        while (self.maxHeap[current] > self.maxHeap[self.parent(current)] and current>1):
            self.scambia(current, self.parent(current))
            current = self.parent(current)
    
#Stampa dell'albero per vedere cosa abbiamo fatto
    def Print(self):
         
        for i in range(0, (self.size // 2)):
            print("PARENT : " + str(self.maxHeap[i]) +
                  " LEFT CHILD : " + str(self.maxHeap[self.leftChild(i)]) +
                  " RIGHT CHILD : " + str(self.maxHeap[self.rightChild(i)]))


### Funzioni per l'ordinamento 

#MAX-HEAPIFY 
#Serve a conservare la proprietà del max heap, viene chiamata quanto gli alberi con radici Left(i) e Righht(i) sono max-heap
#ma A[i] è il più piccolo dei suoi figli, violando la proprietà dell'heap    
def Max_Heapify(A,n,i):
    
    massimo=i #inizializziamo la radice
    
    l=2*i+1 #figlio sinistro
    r=2*i+2 #figlio destro
    
    #Se il nodo non è una foglia e ho un massimo in l
    if l < n and A[l]>A[i]:
        massimo=l
    
    #Se il nodo non è una foglia e ho un massimo in r
    if r < n and A[r]>A[massimo]:
        massimo=r
    
    if massimo != i: #Posso farlo scendere ancora
        (A[i],A[massimo])=(A[massimo],A[i])
        
        Max_Heapify(A,n,massimo)
            
def Build_Max_Heap(A):
    for i in range (len(A)//2,-1,-1):
        Max_Heapify(A,len(A),i)
    return A

#Funzioni delle code a priorità
def Heap_Increase_Key(A,i,key):
    if key<A.maxHeap[i]:
        print("New key is smaller than current key")
    A.maxHeap[i]=key
    while i>0 and A.maxHeap[A.parent(i)]<A.maxHeap[i]:
        A.scambia(i,A.parent(i))
        i=A.parent(i) #Tecnica dei puntatori inseguitori 
        
def Max_Heap_Insert(A, key):
    A.inserisci(float('-inf'))
    print(A.maxHeap)
    Heap_Increase_Key(A,A.size-1,key)

#HOMEWORK
def Build_Max_Heap_v2(A):
    A_heap=MaxHeap(len(A))
    A_heap.size=1
    for i in range (0,len(A)):
        Max_Heap_Insert(A_heap, A[i])
    return A_heap



#Funzione di lettura da file
def readTestFile(path):
    try: 
        testsList = []
        with open(path, 'r') as file:
            for line in file:
                line = line.strip() #così tolgo gli spazi
                if line:
                    numbers=[]
                    for x in line.split():
                        try:
                            if(int(x)<0):
                                raise ValueError
                            numbers.append(int(x))
                        except ValueError:
                            print(f"Errore alla riga {line.strip()}: '{x}'. Devi inserire numeri interi e positivi!")
                            break #Analizzo solo i caratteri corretti
                    testsList.append(numbers)
    except FileNotFoundError:
        print(f"File {path} non trovato.")
    
    return testsList

if __name__=="__main__":
    
    #try:
        #input da tastiera
        #print("Inserisci n numeri interi separato da spazi: ")
        #array_n = input()
        
        testsList = readTestFile(path="./Test12.txt")

        for test in testsList:
            
            if not test:
                break
            
            print("\nBUILD_MAX_HEAP: \n")
            A=Build_Max_Heap(test)
            print(A)
            print("\nBuilding the heap... \n")
            A_heap=Build_Max_Heap_v2(test)
            print("\nBUILD_MAX_HEAP_V2: \n")
            A_heap.Print()
            print(A_heap.maxHeap)
            
            
    #except ValueError:
    #    print("Devi inserire numeri interi!")